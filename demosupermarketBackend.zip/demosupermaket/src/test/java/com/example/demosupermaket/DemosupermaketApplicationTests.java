package com.example.demosupermaket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosupermaketApplicationTests {

    @Test
    void contextLoads() {
    }

}
