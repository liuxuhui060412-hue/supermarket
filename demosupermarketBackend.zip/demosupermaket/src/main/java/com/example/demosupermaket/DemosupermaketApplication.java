package com.example.demosupermaket;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.example.demosupermaket.mapper")
public class DemosupermaketApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemosupermaketApplication.class, args);
    }
}