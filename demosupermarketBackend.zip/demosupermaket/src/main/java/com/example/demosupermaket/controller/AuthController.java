package com.example.demosupermaket.controller;

import com.example.demosupermaket.entity.User;
import com.example.demosupermaket.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserMapper userMapper;

    /**
     * 用户注册接口
     * POST /api/auth/register
     */
    @PostMapping("/register")
    public Map<String, Object> register(@RequestBody Map<String, String> body) {
        Map<String, Object> result = new HashMap<>();

        String username = body.get("username");
        String password = body.get("password");
        String email = body.get("email");

        // 1. 检查参数是否为空
        if (username == null || password == null || email == null) {
            result.put("success", false);
            result.put("message", "用户名、密码、邮箱不能为空");
            return result;
        }

        // 2. 检查用户名是否已存在
        User existingUser = userMapper.findByUsername(username);
        if (existingUser != null) {
            result.put("success", false);
            result.put("message", "用户名已存在");
            return result;
        }

        // 3. 插入新用户（注意：生产环境密码要加密！这里先明文演示）
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(password); // ⚠️ 实际项目请用 BCrypt 加密
        newUser.setEmail(email);
        newUser.setStatus(1); // 启用状态

        int rows = userMapper.insert(newUser);
        if (rows > 0) {
            result.put("success", true);
            result.put("message", "注册成功");
        } else {
            result.put("success", false);
            result.put("message", "注册失败");
        }

        return result;
    }

    /**
     * 用户登录接口（可选，如果你还没写）
     * POST /api/auth/login
     */
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> body) {
        Map<String, Object> result = new HashMap<>();

        String username = body.get("username");
        String password = body.get("password");

        if (username == null || password == null) {
            result.put("success", false);
            result.put("message", "用户名或密码不能为空");
            return result;
        }

        User user = userMapper.findByUsername(username);
        if (user == null) {
            result.put("success", false);
            result.put("message", "用户不存在");
            return result;
        }

        if (!user.getPassword().equals(password)) {
            result.put("success", false);
            result.put("message", "密码错误");
            return result;
        }

        result.put("success", true);
        result.put("message", "登录成功");
        result.put("userId", user.getId()); // 可选：返回用户ID给前端

        return result;
    }
}