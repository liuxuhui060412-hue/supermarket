package com.example.demosupermaket.controller;

import com.example.demosupermaket.entity.Product;
import com.example.demosupermaket.mapper.ProductMapper;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductMapper productMapper;

    public ProductController(ProductMapper productMapper) {
        this.productMapper = productMapper;
    }

    // ==================== 基础 CRUD ====================

    @GetMapping
    public List<Product> getAllProducts() {
        return productMapper.findAll();
    }

    @GetMapping("/{id}")
    public Product getProductById(@PathVariable Long id) {
        return productMapper.findById(id);
    }

    @PostMapping
    public String addProduct(@RequestBody Product product) {
        product.setUserId(1L);
        product.setStatus(1);
        productMapper.insert(product);
        return "添加成功，ID：" + product.getId();
    }

    @PutMapping("/{id}")
    public String updateProduct(@PathVariable Long id, @RequestBody Product product) {
        Product existing = productMapper.findById(id);
        if (existing == null) {
            return "商品不存在";
        }
        if (product.getName() != null) existing.setName(product.getName());
        if (product.getDescription() != null) existing.setDescription(product.getDescription());
        if (product.getPrice() != null) existing.setPrice(product.getPrice());
        if (product.getStock() != null) existing.setStock(product.getStock());
        if (product.getStatus() != null) existing.setStatus(product.getStatus());
        productMapper.update(existing);
        return "修改成功";
    }

    @DeleteMapping("/{id}")
    public String deleteProduct(@PathVariable Long id) {
        productMapper.deleteById(id);
        return "删除成功";
    }

    // ==================== 首页：低库存预警 ====================

    @GetMapping("/low-stock")
    public List<Product> getLowStockProducts() {
        return productMapper.findLowStock(20);
    }

    // ==================== 排序（库存/默认/种类） ====================

    @GetMapping("/sort-by-stock")
    public List<Product> getProductsSorted(@RequestParam(defaultValue = "desc") String order) {
        if ("asc".equalsIgnoreCase(order)) {
            return productMapper.findAllOrderByStockAsc();
        } else if ("default".equalsIgnoreCase(order)) {
            return productMapper.findAllOrderById();
        } else if ("category".equalsIgnoreCase(order)) {
            return productMapper.findAllOrderByCategory();
        } else {
            return productMapper.findAllOrderByStockDesc();
        }
    }

    // ==================== 今日营业额 ====================

    @GetMapping("/today-sales")
    public Map<String, Object> getTodaySales() {
        Map<String, Object> result = new HashMap<>();
        BigDecimal total = productMapper.getTodaySalesTotal();
        result.put("total", total);
        return result;
    }
}