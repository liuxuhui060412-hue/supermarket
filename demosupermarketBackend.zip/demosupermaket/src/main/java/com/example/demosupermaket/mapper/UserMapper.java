package com.example.demosupermaket.mapper;

import com.example.demosupermaket.entity.User;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user WHERE username = #{username}")
    User findByUsername(String username);

    @Insert("INSERT INTO user(username, password, email, status) VALUES(#{username}, #{password}, #{email}, 1)")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);
}