package com.example.demosupermaket.mapper;

import com.example.demosupermaket.entity.Product;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ProductMapper {

    // ==================== 基础 CRUD ====================

    @Select("SELECT * FROM product WHERE deleted = 0")
    List<Product> findAll();

    @Select("SELECT * FROM product WHERE deleted = 0 AND stock <= 20 ORDER BY stock ASC LIMIT #{limit}")
    List<Product> findLowStock(int limit);

    @Select("SELECT * FROM product WHERE id = #{id} AND deleted = 0")
    Product findById(Long id);

    @Insert("INSERT INTO product(name, description, price, stock, user_id, status) " +
            "VALUES(#{name}, #{description}, #{price}, #{stock}, #{userId}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Product product);

    @Update("UPDATE product SET name=#{name}, description=#{description}, price=#{price}, " +
            "stock=#{stock}, status=#{status} WHERE id=#{id}")
    int update(Product product);

    @Update("UPDATE product SET deleted = 1 WHERE id = #{id}")
    int deleteById(Long id);

    // ==================== 排序 ====================

    // 按库存从多到少
    @Select("SELECT * FROM product WHERE deleted = 0 ORDER BY stock DESC")
    List<Product> findAllOrderByStockDesc();

    // 按库存从少到多
    @Select("SELECT * FROM product WHERE deleted = 0 ORDER BY stock ASC")
    List<Product> findAllOrderByStockAsc();

    // 默认：按商品序号（id 升序）
    @Select("SELECT * FROM product WHERE deleted = 0 ORDER BY id ASC")
    List<Product> findAllOrderById();

    // 按商品种类（description）排序 —— 同种类排一起
    @Select("SELECT * FROM product WHERE deleted = 0 ORDER BY description ASC, id ASC")
    List<Product> findAllOrderByCategory();

    // ==================== 今日营业额 ====================

    // 查询今日营业额（需要 sales_record 表）
    @Select("SELECT COALESCE(SUM(total_price), 0) FROM sales_record " +
            "WHERE DATE(created_at) = CURDATE()")
    java.math.BigDecimal getTodaySalesTotal();

    // 查询今日营业额（通用排序入口）
    default List<Product> sortProducts(String order) {
        if ("asc".equalsIgnoreCase(order)) {
            return findAllOrderByStockAsc();
        } else if ("category".equalsIgnoreCase(order)) {
            return findAllOrderByCategory();
        } else if ("default".equalsIgnoreCase(order)) {
            return findAllOrderById();
        } else {
            return findAllOrderByStockDesc();
        }
    }
}